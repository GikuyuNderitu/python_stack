for val in range(5,1000001):
	if(val % 5 == 0):
		print val
