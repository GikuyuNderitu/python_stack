for val in range(1,1000):
	if(val % 2 != 0):
		print val
